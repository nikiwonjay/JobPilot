document.getElementById("add").addEventListener("click", () => {
  const target = document.getElementById("dynamic");
  target.innerHTML =
    '<fieldset><legend>本科教育</legend><label for="bachelor">Undergraduate Institution</label><input id="bachelor"><label for="project">Project Experience</label><textarea id="project"></textarea></fieldset>';
});
document.getElementById("demo").addEventListener("submit", (event) => {
  event.preventDefault();
  document.getElementById("output").textContent =
    "用户手动提交事件已触发（没有发送到网络）。";
});
